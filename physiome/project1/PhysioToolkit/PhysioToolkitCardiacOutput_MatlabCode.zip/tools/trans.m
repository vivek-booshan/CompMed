function  y = trans(x)

y = x([1 2 10 6 5 3 4 7 9 8 11],:);